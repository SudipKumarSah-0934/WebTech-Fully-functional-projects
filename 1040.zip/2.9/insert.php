<?php
include_once('db.php');

// Create connection
$conn = mysqli_connect($localhost, $dbusername, $dbpass, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO users(UserName, Password) 
        VALUES ('$_POST[uname]', '$_POST[pswd]')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
