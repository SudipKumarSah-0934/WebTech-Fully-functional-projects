function required()
{
var empt = document.forms["form1"]["user"].value;
var em = document.forms["form1"]["pass"].value;
if ((empt && em) == "")
{
alert("Please input Values");
return false;
}
else 
{
alert('Logged in');
return true; 
}
}
