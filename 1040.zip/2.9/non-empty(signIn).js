function required()
{
var empt = document.forms["form2"]["uname"].value;
var emp = document.forms["form2"]["pswd"].value;
var em = document.forms["form2"]["pwd"].value;
if ((empt && emp && em ) == "")
{
alert("Please provide value for all fields");
return false;
}
else 
{
alert('Thanks');
return true; 
}
}
