<?php
include_once('db.php');
$link = mysqli_connect("$localhost", "$dbusername", "$dbpass", "$dbname");
$username = $_POST['user'];
$password = $_POST['pass'];
$sql = "SELECT Password FROM users where UserName = '$username'";
$result = mysqli_query($link,$sql);
while($row = mysqli_fetch_assoc($result)){
	$pwFromDB = $row['Password'];
}
if($pwFromDB == $password){
	echo'success';
	header('Location:welcomePage.html');
}else{
	echo'fail';
}
mysqli_close($link);
?>