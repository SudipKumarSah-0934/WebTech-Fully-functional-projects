<?php
$localhost='localhost';
$dbusername='root';
$dbpass='iit123';
$dbname='myFinal';
?>